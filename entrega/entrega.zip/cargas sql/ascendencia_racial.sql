INSERT INTO ECH_DW.ascendenciaRacial(idAscendenciaRacial, raza) VALUES (1,'Afro o Negra');
INSERT INTO ECH_DW.ascendenciaRacial(idAscendenciaRacial, raza) VALUES (2,'Asiatica o Amarilla');
INSERT INTO ECH_DW.ascendenciaRacial(idAscendenciaRacial, raza) VALUES (3,'Blanca');
INSERT INTO ECH_DW.ascendenciaRacial(idAscendenciaRacial, raza) VALUES (4,'Indigena');
INSERT INTO ECH_DW.ascendenciaRacial(idAscendenciaRacial, raza) VALUES (5,'Otra');
