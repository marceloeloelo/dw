INSERT INTO ECH_DW.ingresos(idIngresos, rango) VALUES (1,'Menor 5000');
INSERT INTO ECH_DW.ingresos(idIngresos, rango) VALUES (2,'Entre 5000 y 10000');
INSERT INTO ECH_DW.ingresos(idIngresos, rango) VALUES (3,'Entre 10000 y 15000');
INSERT INTO ECH_DW.ingresos(idIngresos, rango) VALUES (4,'Entre 15000 y 20000');
INSERT INTO ECH_DW.ingresos(idIngresos, rango) VALUES (5,'Entre 20000 y 30000');
INSERT INTO ECH_DW.ingresos(idIngresos, rango) VALUES (6,'Entre 30000 y 40000');
INSERT INTO ECH_DW.ingresos(idIngresos, rango) VALUES (7,'Entre 40000 y 50000');
INSERT INTO ECH_DW.ingresos(idIngresos, rango) VALUES (8,'Entre 50000 y 60000');
INSERT INTO ECH_DW.ingresos(idIngresos, rango) VALUES (9,'Mas de 60000');
