INSERT INTO ECH_DW.sexos(idSexos, sexo) VALUES (1,'Masculino');
INSERT INTO ECH_DW.sexos(idSexos, sexo) VALUES (2,'Femenino');
