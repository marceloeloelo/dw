INSERT INTO tiposVivienda(idTiposVivienda, tipo) VALUES (1,'casa');
INSERT INTO tiposVivienda(idTiposVivienda, tipo) VALUES (2,'apartamento');
INSERT INTO tiposVivienda(idTiposVivienda, tipo) VALUES (3,'otro');
